# Senior-Project
This is the repository for our Senior project for CMAC 4900 and CMAC 4920. The project is creating a housing waitlist form for our university.
![Clarion](https://github.com/user-attachments/assets/fd055668-66bc-4014-bb13-720ffc0f7e73)

![Edinboro](https://github.com/user-attachments/assets/60cb0485-b8b3-44fd-b63a-f828708fe0b7)

![California](https://github.com/user-attachments/assets/5c35fd59-2f66-422d-aa7d-764d5cd99597)
