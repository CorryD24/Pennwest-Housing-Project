<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$email = $_GET['email'] ?? '';
$subject = $_GET['subject'] ?? '';
$requestID = $_GET['requestID'] ?? '';
$form = $_GET['form'] ?? '';

$mail = new PHPMailer(true);

$mail->isSMTP();
$mail->Host = 'vpwcissmtp1.cis.pennwest.edu';
$mail->SMTPAuth = false;

$mail->Username = 'roomchange@cis.pennwest.edu';
$mail->Port = 25;

$mail->setFrom('roomchange@cis.pennwest.edu', 'PennWest Room Assignments');

// email, subject, and body are set when this page is required by the controller when the button is clicked in the detailed view
$mail->addAddress($email);

$mail->isHTML(false);

$mail->Subject = $subject;
$mail->Body = file_get_contents("../datafiles/notification_email.txt");
// Send an alert to notify the admin the email was sent successfully and redirect back to the appropriate detailed view.
try {
    if ($mail->send()) {
        if ($form == 'RoomChange') {
            echo "
            <script>
                alert('Sent Successfully');
                document.location.href = '../controller/controller.php?action=DisplayRoomChangeRequest&RoomChangeRequestID=" . $requestID . "';        
            </script>
            ";
        }
        else{
            echo "
            <script>
                //alert('Sent Successfully');
                alert('Sent Successfully');
                document.location.href = '../controller/controller.php?action=DisplayRoomRequest&RoomRequestID=" . $requestID . "';        
            </script>
            ";
        }
    }
} catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}
    exit; // Ensure the script stops execution here

?>
