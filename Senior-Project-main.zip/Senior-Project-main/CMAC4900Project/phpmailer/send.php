<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if(isset($_POST["send"])){
  $mail = new PHPMailer(true);

  $mail->SMTPDebug = 2; // Or 3 for even more verbose
  $mail->Debugoutput = 'html';


  $mail->isSMTP();
  $mail->Host = 'vpwcissmtp1.cis.pennwest.edu';
  $mail->SMTPAuth = false;
  $mail->Username = 'testing@cis.pennwest.edu'; // Temporary test email
  $mail->Port = 25;

  $mail->setFrom('testing@cis.pennwest.edu');

  $mail->addAddress($_POST["email"]);

  $mail->isHTML(true);

  $mail->Subject = $_POST["subject"];
  $mail->Body = $_POST["message"];

  $mail->send();

  echo
  "
  <script>
  alert('Sent Successfully');
  document.location.href = 'index.php'; // Redirect after sending email
  </script>
  ";
}
?>
