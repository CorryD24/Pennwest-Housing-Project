<?php

    $spBaseUrl = 'https://devweb1.cis.pennwest.edu/~cis411/SSOProject/security/php-saml-master';

    $settingsInfo = array (
        'sp' => array (
            'entityId' => $spBaseUrl.'/demo1/metadata.php',
            'assertionConsumerService' => array (
                'url' => $spBaseUrl.'/demo1/index.php?acs',
            ),
            'singleLogoutService' => array (
                'url' => $spBaseUrl.'/demo1/index.php?sls',
            ),
            'NameIDFormat' => 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
        ),
        'idp' => array (
                        #Virgil
            'entityId' => 'https://sts.windows.net/c6f25e7c-22e4-4537-872d-803622679b7b/',
            'singleSignOnService' => array (
                                #Virgil
                'url' => 'https://login.microsoftonline.com/c6f25e7c-22e4-4537-872d-803622679b7b/saml2',
            ),
            'singleLogoutService' => array (
                                #Virgil
                'url' => 'https://login.microsoftonline.com/c6f25e7c-22e4-4537-872d-803622679b7b/saml2',
            ),
                        #Virgil
            'x509cert' => '-----BEGIN CERTIFICATE-----
                          MIIC8DCCAdigAwIBAgIQUKi9Qne+IaFI0p1Y0a007DANBgkqhkiG9w0BAQsFADA0MTIwMAYDVQQD
                          EylNaWNyb3NvZnQgQXp1cmUgRmVkZXJhdGVkIFNTTyBDZXJ0aWZpY2F0ZTAeFw0yNTA0MDMxNTM5
                          NDRaFw0yODA0MDMxNTM5NDRaMDQxMjAwBgNVBAMTKU1pY3Jvc29mdCBBenVyZSBGZWRlcmF0ZWQg
                          U1NPIENlcnRpZmljYXRlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAr1Zsvi7cIRLW
                          NDPTU1HcN1Hq/0HKaNe//ZyUpZHum6NaWj04RpaJxYzKtX3kupAWvZfjNONIh5f2KjVpTaKjxsr3
                          1097h5cVtHKVwX13VmNDdKXLB6fyFJtyAMG6vlNhRo4uL0kAa8OSn9RBwZZJI8/DrrQsnCP/E82G
                          c0PpBmSU3qugr/TsbKIz6trmShZN7TANDiXHpGDAlgAhbA+H4y+c2yeslRoeStHrrrArstsIiQfp
                          HRo9VocRjEIRjkXvu9dYVEufXVCi4gOoNiaDT7pI5uMg/+YkICRDKfbAQet5Jssy5LinfWnvG9f/
                          PW6S/vwMsc0hVPKdGtU5ERr4PQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQAJ09SdHIRyR8yGH4Nu
                          1t4xQsp+2I4rCHTQtmMCqDhW8ZTRJALERke6GiM+EsjG4D+6/G1Wln/Yb4HT2bwgNWjb78CsDVtv
                          YhfWih0kVpKUla4+OW8kJZBMS8mHNLM1xqnVUWotUC9t2PYxOmq1BUGlpRkFuZj/IR4Qh9U3ruBt
                          5014XSqNavteSAlfoGVaSbaGIRudQ8E4LXtxT1YLC0YbCv4rvfsFi17Cwl6AF2YenyApEndStM7N
                          68F4PjLF8bfLuIac8S14CzS+VvIzSn2t3tq9gfVc3jWreYHNgJtRTnoMjQHlv12dflrQWMKT3XXs
                          Y7moITFWLR9ubCmon8to
                          -----END CERTIFICATE-----',
        ),
    );
